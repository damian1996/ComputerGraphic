#include "Triangle.h"

void Triangle::draw(Image* img, Pen* pen) {

}
Shape* Triangle::transform(Matrix* M) {
    return this;
}
