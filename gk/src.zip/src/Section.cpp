#include "Section.h"

void Section::draw(Image* img, Pen* pen) {

}
Shape* Section::transform(Matrix* M) {
  return this;
}
