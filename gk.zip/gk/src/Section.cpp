#include "Section.h"

void Section::draw(const std::string& shape) {

}
void Section::transform(const std::string& S, const std::string& T, Matrix* M) {

}
