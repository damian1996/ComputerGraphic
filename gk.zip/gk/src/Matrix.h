#ifndef WDGK_MATRIX_HEADER
#define WDGK_MATRIX_HEADER

#include <vector>
#include <string>

class Matrix {
  std::string x;
  uint cols, rows;
  float *mat;
public:
  Matrix();
  Matrix(int cols, int rows);
  ~Matrix();
  float get(uint i, uint j);
  void set(uint i, uint j, float val);
  void fill(std::vector<float> values);
  uint width();
  uint height();
};

#endif
