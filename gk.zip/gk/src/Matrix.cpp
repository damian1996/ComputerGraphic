#include "Matrix.h"

Matrix::Matrix() : cols(0), rows(0) {
}
Matrix::Matrix(int cols, int rows) : cols(cols), rows(rows) {
  mat = new float[rows*cols];
}
Matrix::~Matrix() {
  delete [] mat;
}

float Matrix::get(uint i, uint j) {
  return mat[i*cols + j];
}
void Matrix::set(uint i, uint j, float val) {
  mat[i*cols + j] = val;
}
void Matrix::fill(std::vector<float> values) {
  for(int i=0; i<height(); i++) {
    for(int j=0; j<width(); j++) {
      mat[i*cols + j] = values[i*cols + j];
    }
  }
}
uint Matrix::width() {
  return cols;
}
uint Matrix::height() {
  return rows;
}
