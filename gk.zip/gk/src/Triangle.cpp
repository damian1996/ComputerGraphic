#include "Triangle.h"

void Triangle::draw(const std::string& shape) {

}
void Triangle::transform(const std::string& S, const std::string& T, Matrix* M) {

}
