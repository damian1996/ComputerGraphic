#ifndef WDGK_SHAPE_HEADER
#define WDGK_SHAPE_HEADER

#include "Matrix.h"
#include <string>

class Shape {
public:
  virtual void draw(const std::string& shape) = 0;
  virtual void transform(const std::string& S, const std::string& T, Matrix* M) = 0;
  ~Shape() {

  }
};

#endif
