make
python3 skr.py > tescik
./bin/gk < tescik
